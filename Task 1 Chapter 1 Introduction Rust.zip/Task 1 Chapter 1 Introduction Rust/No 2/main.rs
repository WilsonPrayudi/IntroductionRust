use std::io;
use std::{i32};
 
fn main() {
 
          let mut param1 = String::new();
 
          io::stdin().read_line(&mut param1).expect("Failed to read input");
 
          let mut param2 = String::new();
          io::stdin().read_line(&mut param2).expect("Failed to read input");
 
          let a: i32 = param1.trim().parse().ok().expect("Invalid input");
          let b: i32 = param2.trim().parse().ok().expect("Invalid input");
 
          println!("{}", a % b);
 
}