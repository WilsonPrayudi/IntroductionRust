use std::io;
 
fn main() {
    let mut param1 = String::new();
    let mut param2 = String::new();

    io::stdin().read_line(&mut param1).expect("Failed to read input");
    let param1: String = param1.trim().parse().expect("Invalid input");

    io::stdin().read_line(&mut param2).expect("Failed to read input");
    let param2: String = param2.trim().parse().expect("Invalid input");

    println!("{} {}", param1,param2);

}