struct MyTuple<T: PartialEq>(pub T, pub T);

impl<T: PartialEq> PartialEq for MyTuple<T> {
    fn eq(&self, other: &Self) -> bool {
        self.0 == other.0 || self.1 == other.1
    }
}

impl<T: PartialEq> Eq for MyTuple<T> {}

fn main() {
    let a = MyTuple(1, 2);
    let b = MyTuple(1, 3);
    let c = MyTuple(4, 2);
    let d = MyTuple(3, 1);
    let e = MyTuple(1, 5);
    
    println!("(1, 2) == (4, 2) : {}", a == c);
    println!("(1, 3) == (3, 1) : {}", b == d);
    println!("(1, 3) == (1, 5) : {}", b == e);

}