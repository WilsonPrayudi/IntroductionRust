import math
def is_prime(number):
  if number <= 2:
    print(number, "is prime")
    return True
  for i in range(3, math.floor(math.sqrt(number))+1, 2):
    if number%i == 0:
      print(number, "is prime")
      return True
  print(number, "is not prime")
  return False